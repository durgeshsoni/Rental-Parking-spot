package com.nobroker.teamturingservice.controller;

import com.nobroker.teamturingservice.dto.SocietyAddressDto;
import com.nobroker.teamturingservice.service.ParkingAddressService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/parking/address", produces = MediaType.APPLICATION_JSON_VALUE)
public class ParkingAddressController {
    private final ParkingAddressService parkingAddressService;

    public ParkingAddressController(final ParkingAddressService parkingAddressService) {
        this.parkingAddressService = parkingAddressService;
    }

    @CrossOrigin
    @GetMapping
    public ResponseEntity<?> getParkingAddressFilter(final SocietyAddressDto dto) {
        return ResponseEntity.ok(parkingAddressService.getParkingLocationByFilter(dto));
    }


    @CrossOrigin
    @GetMapping(path = "/{id}")
    public ResponseEntity<?> getParkingAddressById(@PathVariable final String id) {
        return ResponseEntity.ok(parkingAddressService.getSocietyById(id));
    }

    @CrossOrigin
    @GetMapping(path = "city/{city}")
    public ResponseEntity<?> getParkingAddressByCity(@PathVariable final String city) {
        return ResponseEntity.ok(parkingAddressService.getSocietyAddressByCity(city));
    }

    @CrossOrigin
    @PostMapping(path = "/create", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createSocietyAddress(@RequestBody final SocietyAddressDto dto) {
        return ResponseEntity.ok(parkingAddressService.createSocietyAddress(dto));
    }

}
