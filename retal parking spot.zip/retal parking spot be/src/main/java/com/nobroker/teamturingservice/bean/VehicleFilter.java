package com.nobroker.teamturingservice.bean;

import lombok.Data;

@Data
public class VehicleFilter {
    private String userId;
}
