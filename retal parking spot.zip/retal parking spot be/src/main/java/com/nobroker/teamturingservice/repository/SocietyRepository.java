package com.nobroker.teamturingservice.repository;

import com.nobroker.teamturingservice.entity.SocietyAddress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SocietyRepository extends JpaRepository<SocietyAddress, String> {

    List<SocietyAddress> findAllByType(final String type);

    Optional<SocietyAddress> findById(final String id);

    List<SocietyAddress> findAllByCity(final String city);

}
