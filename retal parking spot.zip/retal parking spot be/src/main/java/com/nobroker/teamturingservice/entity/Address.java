package com.nobroker.teamturingservice.entity;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Table(name = "address")
@Entity
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Address extends BaseEntity {
    @Column(name = "address1", table = "address")
    private String address1;
    @Column(name = "address2", table = "address")
    private String address2;
    @Column(name = "city", table = "address")
    private String city;
    @Column(name = "state", table = "address")
    private String state;
    @Column(name = "latitude", table = "address")
    private String latitude;
    @Column(name = "longitude", table = "address")
    private String longitude;
    @Column(name = "type", table = "address", updatable = false, insertable = false)
    private String type;
    @Column(name = "owner_id", table = "address")
    private String ownerId;
    @Column(name = "image_url", table = "address")
    private String imageUrl;

}
