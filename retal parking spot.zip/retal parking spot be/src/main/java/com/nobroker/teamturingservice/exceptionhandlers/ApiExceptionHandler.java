package com.nobroker.teamturingservice.exceptionhandlers;

import com.nobroker.teamturingservice.exception.EntityNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(value = {EntityNotFoundException.class})
    public ResponseEntity<Object> handleAdminException(EntityNotFoundException e) {
        return new ResponseEntity<>(new ApiException(
                e.getMessage()
                , HttpStatus.NOT_FOUND), HttpStatus.NOT_FOUND);
    }

}