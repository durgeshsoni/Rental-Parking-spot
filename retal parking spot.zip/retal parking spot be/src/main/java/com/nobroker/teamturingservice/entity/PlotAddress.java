package com.nobroker.teamturingservice.entity;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;


@NoArgsConstructor
@Entity
@DiscriminatorValue(value = "PLOT")
@SecondaryTable(name = "plot_address",
        pkJoinColumns = {@PrimaryKeyJoinColumn(name = "id", referencedColumnName = "id")})
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PlotAddress extends Address {

    @Column(name = "plot_id", table = "plot_address")
    private String plotId;

}
