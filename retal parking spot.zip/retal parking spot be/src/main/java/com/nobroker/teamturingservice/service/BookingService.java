package com.nobroker.teamturingservice.service;

import com.nobroker.teamturingservice.entity.BookingDetails;
import com.nobroker.teamturingservice.exception.EntityNotFoundException;
import com.nobroker.teamturingservice.repository.BookingDetailsRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
public class BookingService {
    private final BookingDetailsRepository repo;

    public BookingService(BookingDetailsRepository repo) {
        this.repo = repo;
    }

    public BookingDetails bookSlot(final BookingDetails bookingDetails) {
        return repo.save(bookingDetails);
    }

    public BookingDetails upgradeBooking(final BookingDetails upgraded) {
        final Optional<BookingDetails> optional = repo.findById(upgraded.getId());
        if(!optional.isPresent())
            throw new EntityNotFoundException(upgraded.getId());
        final BookingDetails existing = optional.get();
        existing.setExpiry(upgraded.getExpiry());
        return repo.save(existing);
    }
}
