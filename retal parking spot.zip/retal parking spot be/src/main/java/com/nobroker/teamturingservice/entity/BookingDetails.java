package com.nobroker.teamturingservice.entity;

import com.nobroker.teamturingservice.enums.PlanType;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import java.util.Date;

import static com.nobroker.teamturingservice.common.EntityName.BOOKING_DETAILS;

@Data
@Entity
@Table(name = BOOKING_DETAILS)
public class BookingDetails extends BaseEntity {
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "parking_layout_id")
    private ParkingLayout parkingLayout;

    @Embedded
    @Column(name = "plan_type", table = BOOKING_DETAILS)
    private PlanType planType;

    @Column(name = "expiry", table = BOOKING_DETAILS)
    private Date expiry;
}
