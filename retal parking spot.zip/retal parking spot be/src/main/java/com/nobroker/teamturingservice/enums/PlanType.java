package com.nobroker.teamturingservice.enums;

public enum PlanType {
    MONTHLY, YEARLY
}
