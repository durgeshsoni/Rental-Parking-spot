package com.nobroker.teamturingservice.common;

public final class EntityName {

    public static final String USER = "base_user";
    public static final String CLIENT = "client";
    public static final String VEHICLE = "vehicle";
    public static final String BOOKING_DETAILS = "booking_details";
}
