package com.nobroker.teamturingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamTuringServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamTuringServiceApplication.class, args);
	}

}
