package com.nobroker.teamturingservice.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.function.Function;

public class CommonUtils {
    public static <T> T coalesce(final T value, final T defaultValue) {
        boolean check = value == null;
        if (!check && value instanceof String) check = StringUtils.isBlank((String) value);
        return check ? defaultValue : value;
    }

    /**
     * returns first non-null value
     */
    public static <T, R> T coalesce(final R r1, final R r2, final Function<? super R, T> mapper) {
        final T value = r1 == null ? null : mapper.apply(r1);
        final T defaultValue = r2 == null ? null : mapper.apply(r2);
        return coalesce(value, defaultValue);
    }
}
