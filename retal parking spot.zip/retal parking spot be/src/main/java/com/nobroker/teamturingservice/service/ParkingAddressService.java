package com.nobroker.teamturingservice.service;

import com.nobroker.teamturingservice.dto.SocietyAddressDto;
import com.nobroker.teamturingservice.entity.Address;
import com.nobroker.teamturingservice.entity.SocietyAddress;
import com.nobroker.teamturingservice.repository.SocietyRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class ParkingAddressService {

    private final SocietyRepository societyRepository;


    @PersistenceContext
    private EntityManager entityManager;

    public ParkingAddressService(final SocietyRepository societyRepository) {
        this.societyRepository = societyRepository;
    }

    public List<SocietyAddress> getSocietyAddressByCity(final String city) {
        return societyRepository.findAllByCity(city);
    }

    public SocietyAddress getSocietyById(final String id) {
        return societyRepository.findById(id).orElseGet(null);
    }

    public Address createSocietyAddress(SocietyAddressDto dto) {
        SocietyAddress societyAddress = new SocietyAddress();
        societyAddress.setSocietyId(dto.getSocietyId());
        societyAddress.setAddress1(dto.getAddress1());
        societyAddress.setAddress2(dto.getAddress2());
        societyAddress.setCity(dto.getCity());
        societyAddress.setState(dto.getState());
        societyAddress.setLatitude(dto.getLatitude());
        societyAddress.setLongitude(dto.getLongitude());
        societyAddress.setOwnerId(dto.getOwnerId());
        societyAddress.setType(dto.getType());
        return societyRepository.save(societyAddress);
    }

    public List<SocietyAddress> getParkingLocationByFilter(SocietyAddressDto filter) {
        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<SocietyAddress> cq = cb.createQuery(SocietyAddress.class);
        final Root<SocietyAddress> root = cq.from(SocietyAddress.class);
        final List<Predicate> predicates = new ArrayList<>();
        if (ObjectUtils.isNotEmpty(filter.getType())) {
            predicates.add(cb.equal(root.get("type"), filter.getType()));
        }
        if (ObjectUtils.isNotEmpty(filter.getCity())) {
            predicates.add(cb.equal(root.get("city"), filter.getCity()));
        }
        if (ObjectUtils.isNotEmpty(filter.getState())) {
            predicates.add(cb.equal(root.get("state"), filter.getState()));
        }
        if (ObjectUtils.isNotEmpty(filter.getOwnerId())) {
            predicates.add(cb.equal(root.get("owner_id"), filter.getOwnerId()));
        }
        if (ObjectUtils.isNotEmpty(filter.getSocietyId())) {
            predicates.add(cb.equal(root.get("society_id"), filter.getSocietyId()));
        }
        if (ObjectUtils.isNotEmpty(filter.getLatitude())) {
            predicates.add(cb.equal(root.get("latitude"), filter.getLatitude()));
        }
        if (ObjectUtils.isNotEmpty(filter.getLongitude())) {
            predicates.add(cb.equal(root.get("longitude"), filter.getLongitude()));
        }
        cq.select(root).where(predicates.toArray(new Predicate[0]));
        final List<SocietyAddress> result = entityManager.createQuery(cq)
                .setFirstResult(0 * 100)
                .setMaxResults(100).getResultList();
        return result;
    }
}
