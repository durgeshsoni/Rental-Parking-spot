package com.nobroker.teamturingservice.entity;

import com.nobroker.teamturingservice.enums.VehicleType;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import static com.nobroker.teamturingservice.common.EntityName.VEHICLE;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Table(name = VEHICLE)
@Entity
public class Vehicle extends BaseEntity {
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    @Column(name = "name", table = VEHICLE)
    private String name;
    @Embedded
    @Column(name = "vehicle_type", table = VEHICLE)
    private VehicleType vehicleType;
    @Column(name = "registration_number", table = VEHICLE)
    private String regNumber;
    @Column(name = "chassis_number", table = VEHICLE)
    private String chsNumber;
    @Column(name = "engine_number", table = VEHICLE)
    private String engNumber;

}
