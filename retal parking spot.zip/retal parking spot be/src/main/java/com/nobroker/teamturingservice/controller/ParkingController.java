package com.nobroker.teamturingservice.controller;

import com.nobroker.teamturingservice.dto.ParkingLayoutDto;
import com.nobroker.teamturingservice.service.ParkingLayoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/parking-layout")
public class ParkingController {

    @Autowired
    private ParkingLayoutService parkingLayoutService;

    @PostMapping
    public ResponseEntity<?> createParkingLayout(@RequestBody  final ParkingLayoutDto parkingLayout){
        return ResponseEntity.ok(parkingLayoutService.createParkingLayout(parkingLayout));
    }

    @GetMapping
    public ResponseEntity<? > getAllParkingLayout() {
        return ResponseEntity.ok(parkingLayoutService.getAllParkingLayout());
    }
}
