package com.nobroker.teamturingservice.service;

;
import com.nobroker.teamturingservice.dto.ParkingLayoutDto;
import com.nobroker.teamturingservice.entity.ParkingLayout;
import com.nobroker.teamturingservice.repository.ParkingLayoutRepository;
import com.nobroker.teamturingservice.repository.SocietyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParkingLayoutService {

    @Autowired
    private ParkingLayoutRepository parkingLayoutRepository;

    @Autowired
    private SocietyRepository societyRepository;

    public ParkingLayout createParkingLayout(final ParkingLayoutDto parkingLayout){
        final ParkingLayout newParkingLayout = new ParkingLayout();

        newParkingLayout.setAddressId(parkingLayout.getAddressId());
        newParkingLayout.setNoOfFourWheelerSlot(parkingLayout.getNoOfFourWheelerSlot());
        newParkingLayout.setAvailableFourWheelerSlot(parkingLayout.getAvailableFourWheelerSlot());
        newParkingLayout.setAvailableTwoWheelerSlot(parkingLayout.getAvailableTwoWheelerSlot());
        newParkingLayout.setNoOfTwoWheelerSlot(parkingLayout.getNoOfTwoWheelerSlot());
        newParkingLayout.setTwoWheelerPrice(parkingLayout.getTwoWheelerPrice());
        newParkingLayout.setFourWheelerPrice(parkingLayout.getFourWheelerPrice());
       return parkingLayoutRepository.save(newParkingLayout);
    }

    public List<ParkingLayout> getAllParkingLayout() {
        return parkingLayoutRepository.findAll();
    }
}
