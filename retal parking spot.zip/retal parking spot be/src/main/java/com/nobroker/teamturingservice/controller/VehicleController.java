package com.nobroker.teamturingservice.controller;

import com.nobroker.teamturingservice.bean.VehicleFilter;
import com.nobroker.teamturingservice.entity.Vehicle;
import com.nobroker.teamturingservice.service.VehicleService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/vehicle", produces = MediaType.APPLICATION_JSON_VALUE)
public class VehicleController {
    private final VehicleService service;

    public VehicleController(VehicleService service) {
        this.service = service;
    }

    @CrossOrigin
    @GetMapping
    public ResponseEntity<?> getVehicles(final VehicleFilter filter) {
        return ResponseEntity.ok(service.getVehicles(filter));
    }

    @CrossOrigin
    @PostMapping
    public ResponseEntity<?> addVehicle(@RequestBody final Vehicle vehicle) {
        return ResponseEntity.ok(service.createVehicle(vehicle));
    }

    @CrossOrigin
    @PutMapping
    public ResponseEntity<?> removeVehicle(@RequestParam final String id) {
        service.deleteVehicle(id);
        return ResponseEntity.ok("Vehicle deleted: " + id);
    }
}
