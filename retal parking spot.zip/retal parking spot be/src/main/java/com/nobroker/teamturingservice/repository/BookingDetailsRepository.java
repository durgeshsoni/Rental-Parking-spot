package com.nobroker.teamturingservice.repository;

import com.nobroker.teamturingservice.entity.BookingDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingDetailsRepository extends JpaRepository<BookingDetails, String> {
}
