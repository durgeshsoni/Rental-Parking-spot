package com.nobroker.teamturingservice.enums;

public enum VehicleType {
    BIKE, CAR
}
