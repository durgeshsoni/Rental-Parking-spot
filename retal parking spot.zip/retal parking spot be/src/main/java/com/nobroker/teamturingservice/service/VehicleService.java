package com.nobroker.teamturingservice.service;

import com.nobroker.teamturingservice.VehicleRepo;
import com.nobroker.teamturingservice.bean.VehicleFilter;
import com.nobroker.teamturingservice.entity.Vehicle;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class VehicleService {
    private final VehicleRepo vehicleRepo;

    public VehicleService(final VehicleRepo vehicleRepo) {
        this.vehicleRepo = vehicleRepo;
    }

    public List<Vehicle> getVehicles(final VehicleFilter filter) {
        if(StringUtils.isNotBlank(filter.getUserId()))
            return vehicleRepo.findByUserId(filter.getUserId());
        return null;
    }

    public Vehicle createVehicle(final Vehicle vehicle) {
        return vehicleRepo.save(vehicle);
    }

    public void deleteVehicle(final String id) {
        vehicleRepo.deleteById(id);
    }
}
