package com.nobroker.teamturingservice.entity;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import static com.nobroker.teamturingservice.common.EntityName.USER;

@Entity
@Table(name = USER)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class User extends BaseEntity{

    @Column(name = "user_name", table = USER)
    private String userName;

    @Column(name = "user_type", table = USER)
    private String userType;

    @Column(name = "phone_number", table = USER)
    private String phoneNumber;

}
