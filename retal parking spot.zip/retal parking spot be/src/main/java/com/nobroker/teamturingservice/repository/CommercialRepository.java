package com.nobroker.teamturingservice.repository;

import com.nobroker.teamturingservice.entity.Address;
import com.nobroker.teamturingservice.entity.CommercialAddress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CommercialRepository extends JpaRepository<CommercialAddress, String> {

}
