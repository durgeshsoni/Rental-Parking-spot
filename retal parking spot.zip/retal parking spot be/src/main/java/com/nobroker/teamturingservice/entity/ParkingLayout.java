package com.nobroker.teamturingservice.entity;

import lombok.Data;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "parking_layout")
public class ParkingLayout extends BaseEntity {

    @Column(name = "address_id", table = "parking_layout")
    private String addressId;

    @Column(name = "no_of_two_wheeler_slot", table = "parking_layout")
    private Integer noOfTwoWheelerSlot;

    @Column(name = "no_of_four_wheeler_slot", table = "parking_layout")
    private Integer noOfFourWheelerSlot;

    @Column(name = "available_two_wheeler_slot", table = "parking_layout")
    private Integer availableTwoWheelerSlot;

    @Column(name = "available_four_wheeler_slot", table = "parking_layout")
    private Integer availableFourWheelerSlot;

    @Column(name = "two_wheeler_price", table = "parking_layout")
    private Double twoWheelerPrice;

    @Column(name = "four_wheeler_price", table = "parking_layout")
    private Double fourWheelerPrice;


}
