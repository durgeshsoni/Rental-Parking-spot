package com.nobroker.teamturingservice.repository;

import com.nobroker.teamturingservice.entity.ParkingLayout;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParkingLayoutRepository extends JpaRepository<ParkingLayout, String> {

}
