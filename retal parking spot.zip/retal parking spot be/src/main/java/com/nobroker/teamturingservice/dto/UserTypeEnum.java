package com.nobroker.teamturingservice.dto;

public enum UserTypeEnum {
    tenant, owner
}
